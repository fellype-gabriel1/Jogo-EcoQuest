import sqlite3
import json

class SaveManager:
    def __init__(self, db_name="save_game.db"):
        self.db_name = db_name
        self._criar_ou_atualizar_tabela()

    def _criar_ou_atualizar_tabela(self):
        """Cria ou atualiza a tabela mantendo dados antigos"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        # Verifica se a tabela existe
        cursor.execute("""
            SELECT name FROM sqlite_master 
            WHERE type='table' AND name='save'
        """)
        tabela_existe = cursor.fetchone()
        
        if tabela_existe:
            # Tabela existe, verifica se tem coluna itens_equipados
            cursor.execute("PRAGMA table_info(save)")
            colunas = [col[1] for col in cursor.fetchall()]
            
            if 'itens_equipados' not in colunas:
                print("🔄 Atualizando tabela: adicionando coluna 'itens_equipados'...")
                cursor.execute("ALTER TABLE save ADD COLUMN itens_equipados TEXT")
                conn.commit()
                print("✅ Coluna 'itens_equipados' adicionada com sucesso!")
        else:
            # Tabela não existe, cria nova
            cursor.execute("""
                CREATE TABLE save (
                    id INTEGER PRIMARY KEY,
                    x INTEGER,
                    y INTEGER,
                    vida INTEGER,
                    vida_max INTEGER,
                    itens TEXT,
                    mobs TEXT,
                    itens_equipados TEXT
                )
            """)
            conn.commit()
            print("✅ Tabela save criada com coluna 'itens_equipados'")
        
        conn.close()

    def salvar(self, dados):
        """Salva os dados do jogo"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        
        cursor.execute("DELETE FROM save")  # Remove save anterior
        cursor.execute("""
            INSERT INTO save (x, y, vida, vida_max, itens, mobs, itens_equipados)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            dados["x"],
            dados["y"],
            dados["vida"],
            dados["vida_max"],
            json.dumps(dados["itens"]),
            json.dumps(dados["mobs"]),
            json.dumps(dados.get("itens_equipados", []))  # Nova coluna
        ))
        conn.commit()
        conn.close()
        print("💾 Dados salvos no banco (com itens equipados)")

    def carregar(self):
        """Carrega o save do banco"""
        conn = sqlite3.connect(self.db_name)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM save LIMIT 1")
        row = cursor.fetchone()
        conn.close()
        
        if not row:
            print("📭 Nenhum save encontrado no banco")
            return None
        
        print(f"📂 Save encontrado no banco: {len(row)} colunas")
        
        # Para compatibilidade com saves antigos
        itens_data = json.loads(row[5]) if row[5] else []
        mobs_data = json.loads(row[6]) if len(row) > 6 and row[6] else []
        itens_equipados_data = json.loads(row[7]) if len(row) > 7 and row[7] else []
        
        print(f"📦 {len(itens_data)} itens, {len(itens_equipados_data)} itens equipados, {len(mobs_data)} mobs carregados")
        
        dados_carregados = {
            "x": row[1],
            "y": row[2],
            "vida": row[3],
            "vida_max": row[4],
            "itens": itens_data,
            "mobs": mobs_data,
            "itens_equipados": itens_equipados_data
        }
        
        print(f"🎯 Dados carregados: posição=({dados_carregados['x']}, {dados_carregados['y']})")
        return dados_carregados