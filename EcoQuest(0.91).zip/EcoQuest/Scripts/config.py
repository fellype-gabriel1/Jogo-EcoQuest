TELA_LARGURA = 1056
TELA_ALTURA = 720
FPS = 60
CORES = {
    "preto": (0, 0, 0),
    "branco": (255, 255, 255),
    "cinza":(150, 150, 150),
    "marrom escuro": (145, 79, 40),
    "marrom claro": (188, 98, 43)
}