import pygame
from pytmx import load_pygame, TiledTileLayer

class Map:
    def __init__(self, tmx_file):
        self.tmx_data = load_pygame(tmx_file)
        self.largura = self.tmx_data.width * self.tmx_data.tilewidth
        self.altura = self.tmx_data.height * self.tmx_data.tileheight
        self.obstaculos = self.carregar_obstaculos()

    def carregar_obstaculos(self):
        """Carrega obstáculos da camada de objetos 'Obstaculos'"""
        obstaculos = []
        
        print(" Procurando camada de obstáculos...")
        
        # Procura pela camada de objetos chamada "Obstaculos"
        for layer in self.tmx_data.layers:
            if hasattr(layer, 'name') and layer.name == "Obstaculos":
                print(f" Camada de obstáculos encontrada: {layer.name}")
                for obj in layer:
                    # Cria um retângulo de colisão para cada objeto
                    rect = pygame.Rect(obj.x, obj.y, obj.width, obj.height)
                    obstaculos.append(rect)
                    print(f"   📦 Obstáculo: ({obj.x}, {obj.y}, {obj.width}, {obj.height})")
        
        print(f" Total de obstáculos carregados: {len(obstaculos)}")
        return obstaculos

    def draw(self, tela, camera_offset):
        offset_x, offset_y = camera_offset
        for layer in self.tmx_data.visible_layers:
            if isinstance(layer, TiledTileLayer):
                for x, y, gid in layer:
                    tile = self.tmx_data.get_tile_image_by_gid(gid)
                    if tile:
                        tela.blit(tile, (x * self.tmx_data.tilewidth - offset_x,
                                         y * self.tmx_data.tileheight - offset_y))

    def get_size(self):
        return self.largura, self.altura