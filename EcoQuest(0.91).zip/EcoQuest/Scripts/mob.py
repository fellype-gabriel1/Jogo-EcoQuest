import pygame
import random
import math

class Mob(pygame.sprite.Sprite):
    def __init__(self, x, y, spritesheet_path, obstaculos, mobs_group):
        super().__init__()
        self.spritesheet_path = pygame.image.load(spritesheet_path).convert_alpha()

        # Tamanho do frame (a spritesheet é 64x64 → 16x16 cada frame)
        self.frame_width = self.spritesheet_path.get_width() // 4
        self.frame_height = self.spritesheet_path.get_height() // 4

        # Animações
        self.animations = {
            "down": [],
            "left": [],
            "right": [],
            "up": []
        }
        self.load_frames()

        # CORREÇÃO: Definir uma imagem padrão ANTES de chamar safe_spawn
        self.image = self.animations["down"][0]  # Imagem padrão
        self.image = pygame.transform.scale(self.image, (48, 48))  # zoom

        # Posição segura (não nascer em colisão com obstáculo ou outro mob)
        if x is None or y is None:
            self.rect = self.safe_spawn(obstaculos, mobs_group)
        else:
            self.rect = self.image.get_rect(topleft=(x, y))

        # Hitbox menor para colisão mais precisa (30x30 em vez de 48x48)
        self.hitbox = pygame.Rect(0, 0, 30, 30)
        self.update_hitbox()

        self.direction = "down"
        self.animation_index = 0
        self.animation_timer = 0
        self.animation_speed = 0.15

        # posição em float para movimento suave
        self.pos = pygame.math.Vector2(self.rect.topleft)
        self.vel = pygame.math.Vector2(0, 0)

        
        self.vida_max = 50
        self.vida_atual = self.vida_max
        self.speed = 1.4
        self.percepcao = 200
        self.dano = 5  # Dano que o mob causa

        # SISTEMA DE STUN - ADICIONE ESTAS 3 LINHAS
        self.stunned = False
        self.stun_timer = 0
        self.stun_duration = 500  # 0.5 segundo em milissegundos

        # animação
        self.frame_index = 0

        self.obstaculos = obstaculos
        self.mobs_group = mobs_group

    def update_hitbox(self):
        """Atualiza a posição da hitbox para ficar centralizada no mob"""
        self.hitbox.center = self.rect.center

    def safe_spawn(self, obstaculos, mobs_group):
        """Garante que o mob não nasça dentro de obstáculo ou outro mob"""
        max_attempts = 100
        for _ in range(max_attempts):
            x = random.randint(50, 2000)
            y = random.randint(50, 2000)
            temp_rect = pygame.Rect(x, y, 48, 48)  # Usar 48 que é o tamanho do mob

            # colisão com obstáculos
            if any(temp_rect.colliderect(obs) for obs in obstaculos):
                continue
            # colisão com outros mobs
            if any(temp_rect.colliderect(mob.rect) for mob in mobs_group):
                continue

            # CORREÇÃO: self.image já está definida agora
            return self.image.get_rect(topleft=(x, y))
        
        # Fallback se não encontrar posição
        return self.image.get_rect(topleft=(300, 300))

    def load_frames(self):
        directions = ["down", "left", "right", "up"]
        zoom = 3

        for row, direction in enumerate(directions):
            for col in range(4):
                x = col * self.frame_width
                y = row * self.frame_height
                frame = self.spritesheet_path.subsurface(
                    pygame.Rect(x, y, self.frame_width, self.frame_height)
                )
                frame = pygame.transform.scale(
                    frame, (self.frame_width * zoom, self.frame_height * zoom)
                )
                self.animations[direction].append(frame)

    def update(self, player):
        if self.stunned:
            current_time = pygame.time.get_ticks()
            if current_time - self.stun_timer >= self.stun_duration:
                self.stunned = False

            else:
                # Se está stunnado, não se move
                self.vel.x = 0
                self.vel.y = 0
                # Frame parado durante stun
                self.animation_index = 0
                self.image = self.animations[self.direction][0]
                return

        dx = player.rect.centerx - self.rect.centerx
        dy = player.rect.centery - self.rect.centery
        distancia = math.hypot(dx, dy)

        self.vel.x = 0
        self.vel.y = 0

        if distancia <= self.percepcao and distancia > 0:
            nx = dx / distancia
            ny = dy / distancia
            self.vel.x = nx * self.speed
            self.vel.y = ny * self.speed

            if abs(nx) > abs(ny):
                self.direction = "right" if nx > 0 else "left"
            else:
                self.direction = "down" if ny > 0 else "up"

        # movimento X com colisão
        self.pos.x += self.vel.x
        self.rect.x = int(self.pos.x)
        self._colisao_axis('x')

        # movimento Y com colisão
        self.pos.y += self.vel.y
        self.rect.y = int(self.pos.y)
        self._colisao_axis('y')

        # Atualiza a hitbox após o movimento
        self.update_hitbox()

        # Atualizar animação
        if self.vel.x != 0 or self.vel.y != 0:
            self.animate()
        else:
            # Frame parado
            self.animation_index = 0
            self.image = self.animations[self.direction][0]

    def tomar_dano(self, dano):
        """Aplica dano ao mob e retorna True se o mob morreu"""
        self.vida_atual = max(0, self.vida_atual - dano)
        print(f"Mob tomou {dano} de dano! Vida: {self.vida_atual}/{self.vida_max}")
        
        # ADICIONE ESTAS 2 LINHAS: Aplica stun quando toma dano
        self.stunned = True
        self.stun_timer = pygame.time.get_ticks()
        print("Mob ficou atordoado!")
        
        return self.vida_atual <= 0  # Retorna True se o mob morreu

    def draw_health_bar(self, tela, camera_offset):
        """Desenha a barra de vida acima do mob"""
        if self.vida_atual < self.vida_max:  # Só mostra se não estiver com vida cheia
            # Posição na tela considerando a câmera
            screen_x = self.rect.x - camera_offset[0]
            screen_y = self.rect.y - camera_offset[1] - 8  # Um pouco acima do mob
            
            # Tamanho da barra
            bar_width = 40
            bar_height = 4
            
            # Fundo da barra (vermelho)
            background_rect = pygame.Rect(screen_x, screen_y, bar_width, bar_height)
            pygame.draw.rect(tela, (255, 0, 0), background_rect)
            
            # Vida atual (verde)
            health_width = int(bar_width * (self.vida_atual / self.vida_max))
            if health_width > 0:
                health_rect = pygame.Rect(screen_x, screen_y, health_width, bar_height)
                pygame.draw.rect(tela, (0, 255, 0), health_rect)

    # (OPCIONAL) Adicione este método para efeito visual durante stun
    def draw_stun_effect(self, tela, camera_offset):
        """Desenha um efeito visual quando o mob está atordoado"""
        if self.stunned:
            screen_x = self.rect.x - camera_offset[0]
            screen_y = self.rect.y - camera_offset[1] - 15
            # Desenha um círculo amarelo acima do mob
            pygame.draw.circle(tela, (255, 255, 0), (screen_x + 24, screen_y), 5)

    def animate(self):
        self.animation_timer += self.animation_speed
        if self.animation_timer >= 1:
            self.animation_timer = 0
            self.animation_index = (self.animation_index + 1) % len(self.animations[self.direction])
            self.image = self.animations[self.direction][self.animation_index]

    def _colisao_axis(self, axis):
        """Colisão com obstáculos e outros mobs"""
        for obs in self.obstaculos:
            if self.rect.colliderect(obs):
                if axis == 'x':
                    if self.vel.x > 0:
                        self.rect.right = obs.left
                    elif self.vel.x < 0:
                        self.rect.left = obs.right
                    self.pos.x = self.rect.x
                elif axis == 'y':
                    if self.vel.y > 0:
                        self.rect.bottom = obs.top
                    elif self.vel.y < 0:
                        self.rect.top = obs.bottom
                    self.pos.y = self.rect.y
                # Atualiza hitbox após colisão
                self.update_hitbox()

        # colisão com outros mobs
        for mob in self.mobs_group:
            if mob != self and self.rect.colliderect(mob.rect):
                if axis == 'x':
                    if self.vel.x > 0:
                        self.rect.right = mob.rect.left
                    elif self.vel.x < 0:
                        self.rect.left = mob.rect.right
                    self.pos.x = self.rect.x
                elif axis == 'y':
                    if self.vel.y > 0:
                        self.rect.bottom = mob.rect.top
                    elif self.vel.y < 0:
                        self.rect.top = mob.rect.bottom
                    self.pos.y = self.rect.y
                # Atualiza hitbox após colisão
                self.update_hitbox()