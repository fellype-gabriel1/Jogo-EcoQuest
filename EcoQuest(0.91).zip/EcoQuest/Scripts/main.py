import pygame
from jogo import Game
from menu import Menu


pygame.init()
tela = pygame.display.set_mode((1056, 720))
pygame.display.set_caption("EcoQuest")


game = Game(tela)


game.run()