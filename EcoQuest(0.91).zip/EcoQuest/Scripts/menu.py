import pygame
import os
from config import TELA_LARGURA, TELA_ALTURA, CORES

class Menu:
    def __init__(self, tela, tipo='inicial', fundo=None):
        self.tela = tela
        self.fundo = fundo
        self.tipo = tipo
        self.opcao_selecionada = 0
        self.opcao_escolhida = None
        
        # Configurações específicas para cada tipo de menu
        if tipo == 'inicial':
            self.opcoes = ['Novo Jogo', 'Continuar', 'Controles', 'Créditos', 'Sair']
            self.fonte = pygame.font.Font("PressStart2P-Regular.ttf", 24)
            self.imagem_fundo = self.carregar_imagem_fundo()
            self.musica_menu = self.carregar_musica_menu()
        elif tipo == 'pausa':
            self.opcoes = ['Continuar', 'Salvar', 'Controles', 'Salvar e Sair']
            self.fonte = pygame.font.Font("PressStart2P-Regular.ttf", 40)
            self.imagem_fundo = None
            self.musica_menu = None

    def carregar_imagem_fundo(self):
        """Carrega a imagem de fundo do menu inicial"""
        caminhos_imagem = [
            "../img/Menu/Menu_Jogo (1).png",  
            "img/Menu/Menu_Jogo (1).png",     
            "Menu_Jogo (1).png"               
        ]
        for caminho in caminhos_imagem:
            if os.path.exists(caminho):
                imagem = pygame.image.load(caminho)
                return pygame.transform.scale(imagem, (TELA_LARGURA, TELA_ALTURA))
        print(" Imagem de fundo não encontrada.")
        return None

    def carregar_musica_menu(self):
        """Carrega a música do menu inicial"""
        caminhos_musica = [
            "../sons/Nanashi-no-Game-Sound-EP-01-Nameless-Theme-Leress-_youtube_.ogg",
            "sons/Nanashi-no-Game-Sound-EP-01-Nameless-Theme-Leress-_youtube_.ogg"
        ]
        for caminho in caminhos_musica:
            if os.path.exists(caminho):
                pygame.mixer.music.load(caminho)
                return True
        print(" Música do menu não encontrada.")
        return False

    def draw(self):
        """Desenha o menu na tela"""
        if self.tipo == 'pausa':
            if self.fundo:
                self.tela.blit(self.fundo, (0, 0))
            overlay = pygame.Surface((TELA_LARGURA, TELA_ALTURA), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 180))
            self.tela.blit(overlay, (0, 0))
        else:
            if self.imagem_fundo:
                self.tela.blit(self.imagem_fundo, (0, 0))
            else:
                self.tela.fill(CORES['preto'])

        for i, opcao in enumerate(self.opcoes):
            cor = CORES['branco'] if i == self.opcao_selecionada else CORES['cinza']
            texto = self.fonte.render(opcao, False, cor)
            x = (TELA_LARGURA - texto.get_width()) // 2
            y = 400 + i * 50 if self.tipo == 'inicial' else 250 + i * 60
            self.tela.blit(texto, (x, y))

        pygame.display.flip()

    def run(self):
        """Loop principal do menu"""
        rodando = True
        clock = pygame.time.Clock()
    
        if self.tipo == 'inicial' and self.musica_menu:
            pygame.mixer.music.play(-1)
            pygame.mixer.music.set_volume(0.5)

        while rodando:
            self.draw()

            for evento in pygame.event.get():
                if evento.type == pygame.QUIT:
                    pygame.quit()
                    exit()

                elif evento.type == pygame.KEYDOWN:
                    if evento.key == pygame.K_UP:
                        self.opcao_selecionada = (self.opcao_selecionada - 1) % len(self.opcoes)
                    elif evento.key == pygame.K_DOWN:
                        self.opcao_selecionada = (self.opcao_selecionada + 1) % len(self.opcoes)
                    elif evento.key == pygame.K_RETURN:
                    
                        acao = self.executar_opcao()
                        if acao:  # Só retorna se não for None
                            return acao
                    elif evento.key == pygame.K_ESCAPE and self.tipo == 'pausa':
                        return "continuar"

                elif evento.type == pygame.MOUSEMOTION:
                    self.detectar_mouse_motion()

                elif evento.type == pygame.MOUSEBUTTONDOWN:
                    if evento.button == 1:
                        acao = self.executar_opcao()
                        if acao:  # Só retorna se não for None
                            return acao

            clock.tick(60)
    
        return None  # Garante que sempre retorna algo

    def detectar_mouse_motion(self):
        """Detecta movimento do mouse para seleção"""
        mouse_x, mouse_y = pygame.mouse.get_pos()
        for i, opcao in enumerate(self.opcoes):
            x = (TELA_LARGURA - 400) // 2
            y = 400 + i * 50 if self.tipo == 'inicial' else 250 + i * 60
            texto_rect = pygame.Rect(x, y, 400, 50)
            if texto_rect.collidepoint(mouse_x, mouse_y):
                self.opcao_selecionada = i

    def executar_opcao(self):
        """Retorna uma string indicando a ação desejada"""
        opcao = self.opcoes[self.opcao_selecionada]

        if opcao == "Novo Jogo":
            if self.tipo == 'inicial':
                pygame.mixer.music.stop()
            return "novo"

        elif opcao == "Continuar":
            if self.tipo == 'inicial':
                pygame.mixer.music.stop()
            return "continuar"

        elif opcao == "Salvar":
            return "salvar"

        elif opcao == "Salvar e Sair":
            return "salvar_sair"

        elif opcao == "Controles":
            print("Controles (não implementado)")
            return "opcoes"

        elif opcao == "Créditos":
            print("Créditos (não implementado)")
            return "creditos"

        elif opcao == "Sair":
            pygame.quit()
            exit()

        return None
