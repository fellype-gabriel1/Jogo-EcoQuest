import pygame
import os
import random
from config import FPS, CORES
from player import Player
from map import Map
from menu import Menu
from hud import Hud
from inventory import Inventory
from mob import Mob
from status import Playerstatus
from save import SaveManager


class Game:
    def __init__(self, tela):
        self.tela = tela
        self.clock = pygame.time.Clock()
        self.running = True
        self.game_over = False

        self.save_manager = SaveManager()

        # Menu inicial
        menu_inicial = Menu(self.tela, tipo='inicial')
        acao_inicial = menu_inicial.run()

        # CORREÇÃO: Lógica completamente refeita
        if acao_inicial == "continuar":
            dados_save = self.save_manager.carregar()
            if dados_save:
                self.inicializar_jogo_com_save(dados_save)
                print("✅ Save carregado com sucesso!")
            else:
                self.inicializar_jogo_novo()
                print("❌ Nenhum save encontrado. Iniciando novo jogo.")
        else:
            self.inicializar_jogo_novo()

        # Música do jogo
        self.musica_jogo = self.carregar_musica_jogo()
        
        # Sistema de dano
        self.damage_cooldown = 0
        self.damage_cooldown_max = 60
        
        # Som de dano
        self.som_dano = self.carregar_som_dano()

    def inicializar_jogo_novo(self):
        """Inicializa um novo jogo com valores padrão"""
        self.game_over = False
        self.map = Map(r'img\tileset\map\mapa01.tmx')
        self.player = Player(x=100, y=100, spritesheets_path=r'img\tileset\personagens\Nilo_reorganizado.png')
        
        # Status padrão
        self.player.status.vida_atual = 100
        self.player.status.vida_max = 100
        
        self._inicializar_componentes_restantes()
        
        # NOVO: Cria mobs padrão
        self.criar_mobs_padrao()
        
        print("🎮 Novo jogo iniciado")

    def inicializar_jogo_com_save(self, dados):
        """Inicializa o jogo com dados do save"""
        print(f"🎮 Inicializando jogo com save: dados recebidos = {dados is not None}")
        
        if not dados:
            print("❌ Dados do save estão vazios, criando novo jogo...")
            self.inicializar_jogo_novo()
            return
        
        # CORREÇÃO: Cria player direto na posição do save
        self.game_over = False
        self.map = Map(r'img\tileset\map\mapa01.tmx')
        self.player = Player(x=dados["x"], y=dados["y"], spritesheets_path=r'img\tileset\personagens\Nilo_reorganizado.png')
        
        # Status do save
        self.player.status.vida_atual = dados["vida"]
        self.player.status.vida_max = dados["vida_max"]
        
        self._inicializar_componentes_restantes()
        
        # CARREGA OS ITENS DO SAVE - CORREÇÃO: ESTADO EXATO
        self.carregar_itens_do_save(dados.get("itens", []), dados.get("itens_equipados", []))
        
        # Carrega os mobs do save
        self.carregar_mobs_do_save(dados.get("mobs", []))
        
        print(f"📂 Save carregado: posição=({dados['x']}, {dados['y']}), vida={dados['vida']}/{dados['vida_max']}, {len(dados.get('itens', []))} itens, {len(dados.get('itens_equipados', []))} equipados, {len(dados.get('mobs', []))} mobs")
        
        # DEBUG: Mostra estado final do carregamento
        self.debug_estado_itens()

    def carregar_itens_do_save(self, itens_data, itens_equipados_data):
        """Carrega os itens preservando o estado exato do save"""
        print(f"🎒 Carregando {len(itens_data)} itens e {len(itens_equipados_data)} itens equipados do save...")
        
        # LIMPA COMPLETAMENTE os itens atuais
        self.player.status.inventario.clear()
        self.player.status.equipped_items.clear()
        
        # CORREÇÃO: Carrega itens do inventário EXATAMENTE como estavam
        for item_data in itens_data:
            try:
                # Formato: {'id': 0, 'name': 'Espada', 'type': 'arma_principal', 'quantity': 1}
                if isinstance(item_data, dict) and 'id' in item_data:
                    # CORREÇÃO: Cria o item exatamente como estava no save
                    item_carregado = {
                        'id': item_data['id'],
                        'name': item_data.get('name', 'Item'),
                        'type': item_data.get('type', 'consumivel'),
                        'quantity': item_data.get('quantity', 1)
                    }
                    # CORREÇÃO: Adiciona diretamente à lista (não usa adicionar_item para preservar estado)
                    self.player.status.inventario.append(item_carregado)
                    print(f"✅ Item '{item_data.get('name', 'Item')}' (x{item_data.get('quantity', 1)}) carregado do save")
                    
            except Exception as e:
                print(f"❌ Erro ao carregar item '{item_data}': {e}")
        
        # CORREÇÃO: Carrega itens equipados EXATAMENTE como estavam
        for item_equipado in itens_equipados_data:
            try:
                if isinstance(item_equipado, dict) and 'id' in item_equipado:
                    # CORREÇÃO: Cria o item equipado exatamente como estava
                    item_equipado_carregado = {
                        'id': item_equipado['id'],
                        'name': item_equipado.get('name', 'Item'),
                        'type': item_equipado.get('type', 'consumivel'),
                        'quantity': item_equipado.get('quantity', 1)
                    }
                    # CORREÇÃO: Adiciona diretamente aos equipados
                    self.player.status.equipped_items.append(item_equipado_carregado)
                    print(f"🛡️ Item equipado '{item_equipado.get('name', 'Item')}' carregado do save")
                    
            except Exception as e:
                print(f"❌ Erro ao carregar item equipado '{item_equipado}': {e}")
        
        print(f"🎒 Total de itens carregados: {len(self.player.status.inventario)}")
        print(f"🛡️ Total de itens equipados: {len(self.player.status.equipped_items)}")
        
        # DEBUG: Mostra estado final
        print("=== ESTADO FINAL DO CARREGAMENTO ===")
        for item in self.player.status.inventario:
            print(f"📦 Inventário: {item['name']} (x{item['quantity']})")
        for item in self.player.status.equipped_items:
            print(f"🛡️ Equipado: {item['name']}")

    def debug_estado_itens(self):
        """Método para debug do estado dos itens"""
        print("\n=== DEBUG ESTADO DOS ITENS ===")
        print("📦 INVENTÁRIO:")
        for item in self.player.status.inventario:
            print(f"   - {item['name']} (ID: {item['id']}, Tipo: {item['type']}, Quantidade: {item['quantity']})")
        
        print("🛡️ ITENS EQUIPADOS:")
        for item in self.player.status.equipped_items:
            print(f"   - {item['name']} (ID: {item['id']}, Tipo: {item['type']})")
        
        print("=" * 40)

    def criar_mobs_padrao(self):
        """Cria mobs padrão para um novo jogo"""
        print("🐺 Criando mobs padrão...")
        
        # Limpa mobs existentes (se houver)
        for mob in self.mobs:
            mob.kill()
        
        # Cria 20 mobs em posições aleatórias
        mobs_criados = 0
        tentativas = 0
        max_tentativas = 100
        
        while mobs_criados < 20 and tentativas < max_tentativas:
            # Gera posições aleatórias dentro do mapa
            x = random.randint(100, self.map_largura - 100)
            y = random.randint(100, self.map_altura - 100)
            
            # Verifica se a posição não colide com o player inicial
            player_rect = pygame.Rect(100, 100, self.player.rect.width, self.player.rect.height)
            mob_rect = pygame.Rect(x, y, 48, 48)  # Tamanho do mob
            
            if not player_rect.colliderect(mob_rect):
                try:
                    mob = Mob(
                        x=x, 
                        y=y, 
                        spritesheet_path=r"img\tileset\mob\SpriteSheet.png", 
                        obstaculos=self.map.obstaculos, 
                        mobs_group=self.mobs
                    )
                    self.mobs.add(mob)
                    self.all_sprites.add(mob)
                    mobs_criados += 1
                    print(f"✅ Mob {mobs_criados} criado em ({x}, {y})")
                except Exception as e:
                    print(f"❌ Erro ao criar mob: {e}")
            
            tentativas += 1
        
        if mobs_criados < 20:
            print(f"⚠️ Apenas {mobs_criados} mobs puderam ser criados (limite de tentativas)")
        
        print(f"🎯 {mobs_criados} mobs criados com sucesso!")

    def carregar_mobs_do_save(self, mobs_data):
        """Carrega os mobs a partir dos dados do save"""
        print(f"🐺 Carregando {len(mobs_data)} mobs do save...")
        
        # Limpa os mobs atuais
        for mob in self.mobs:
            mob.kill()
        
        mobs_carregados = 0
        # Cria novos mobs baseados nos dados do save
        for i, mob_info in enumerate(mobs_data):
            try:
                mob = Mob(
                    x=mob_info["x"], 
                    y=mob_info["y"], 
                    spritesheet_path=r"img\tileset\mob\SpriteSheet.png", 
                    obstaculos=self.map.obstaculos, 
                    mobs_group=self.mobs
                )
                
                # Define a vida do mob
                mob.vida_atual = mob_info["vida"]
                mob.vida_max = mob_info["vida_max"]
                
                self.mobs.add(mob)
                self.all_sprites.add(mob)
                mobs_carregados += 1
                print(f"✅ Mob {i+1} carregado em ({mob_info['x']}, {mob_info['y']}) - Vida: {mob_info['vida']}/{mob_info['vida_max']}")
                
            except Exception as e:
                print(f"❌ Erro ao carregar mob {i}: {e}")
        
        print(f"🎯 {mobs_carregados} mobs carregados do save!")

    def _inicializar_componentes_restantes(self):
        """Inicializa componentes restantes do jogo (após player e map)"""
        # HUD
        self.fundo_hud = pygame.image.load(r'img\HUD\BackgroundBottle.png')
        self.hp = pygame.image.load(r'img\HUD\ProgressHealth.png')
        self.mana = pygame.image.load(r'img\HUD\ProgressWhite.png')
        self.hud = Hud(self.tela)

        # Inventário
        self.inventory = Inventory()
        self.icons = pygame.image.load(r'img\itens\Sprite.png').convert_alpha()

        self.map_largura, self.map_altura = self.map.get_size()
        self.camera_offset = [0, 0]

        # Sprites
        self.all_sprites = pygame.sprite.Group()
        self.mobs = pygame.sprite.Group()
        
        # Adiciona player
        self.all_sprites.add(self.player)
        
        # Cria obstáculos se não existirem
        if not hasattr(self.map, 'obstaculos'):
            self.map.obstaculos = []

    def carregar_musica_jogo(self):
        """Carrega a música de fundo do jogo"""
        try:
            caminhos_musica = [
                "../sons/1 - Adventure Begin.ogg",
                "sons/1 - Adventure Begin.ogg"
            ]
            
            for caminho in caminhos_musica:
                if os.path.exists(caminho):
                    pygame.mixer.music.load(caminho)
                    return True
            
            print("Música do jogo não encontrada.")
            return False
        except pygame.error as e:
            print(f"Erro ao carregar música: {e}")
            return False
        
    def carregar_som_dano(self):
        """Carrega o som de dano do player"""
        try:
            caminho_som = "sons/Hit7.ogg"
            
            if os.path.exists(caminho_som):
                som = pygame.mixer.Sound(caminho_som)
                som.set_volume(0.7)
                print(f"Som de dano carregado: {caminho_som}")
                return som
            else:
                print(f"Arquivo não encontrado: {caminho_som}")
                return None
                
        except Exception as e:
            print(f"Erro ao carregar som: {e}")
            return None

    # =========================
    #  SALVAR E CARREGAR
    # =========================
    def salvar_jogo(self):
        """Salva o estado atual EXATO do jogo"""
        # CORREÇÃO: Prepara lista de itens para salvar - ESTADO ATUAL EXATO
        itens_para_salvar = []
        if hasattr(self.player.status, 'inventario'):
            # CORREÇÃO: Agrupa itens preservando quantidades EXATAS
            itens_agrupados = {}
            for item in self.player.status.inventario:
                chave = (item.get('id', 0), item.get('name', 'Item'), item.get('type', 'consumivel'))
                if chave not in itens_agrupados:
                    itens_agrupados[chave] = {
                        'id': item.get('id', 0),
                        'name': item.get('name', 'Item'),
                        'type': item.get('type', 'consumivel'),
                        'quantity': 0
                    }
                itens_agrupados[chave]['quantity'] += 1
            
            itens_para_salvar = list(itens_agrupados.values())
            print(f"📦 Itens para salvar: {len(itens_para_salvar)} (com quantidades EXATAS)")
        
        # CORREÇÃO: Prepara lista de itens equipados - ESTADO ATUAL EXATO
        itens_equipados_para_salvar = []
        if hasattr(self.player.status, 'equipped_items'):
            # CORREÇÃO: Salva os itens equipados exatamente como estão
            for item in self.player.status.equipped_items:
                item_equipado = {
                    'id': item.get('id', 0),
                    'name': item.get('name', 'Item'),
                    'type': item.get('type', 'consumivel'),
                    'quantity': item.get('quantity', 1)
                }
                itens_equipados_para_salvar.append(item_equipado)
            print(f"🛡️ Itens equipados para salvar: {len(itens_equipados_para_salvar)} (estado EXATO)")
        
        # Prepara dados dos mobs para salvar
        mobs_para_salvar = []
        for mob in self.mobs:
            mob_data = {
                "x": mob.rect.x,
                "y": mob.rect.y,
                "vida": mob.vida_atual,
                "vida_max": mob.vida_max,
                "tipo": "mob_generico"
            }
            mobs_para_salvar.append(mob_data)
        
        dados = {
            "x": self.player.rect.x,
            "y": self.player.rect.y,
            "vida": self.player.status.vida_atual,
            "vida_max": self.player.status.vida_max,
            "itens": itens_para_salvar,
            "itens_equipados": itens_equipados_para_salvar,
            "mobs": mobs_para_salvar
        }
        self.save_manager.salvar(dados)
        print(f"💾 Jogo salvo com sucesso! {len(itens_para_salvar)} itens, {len(itens_equipados_para_salvar)} equipados, {len(mobs_para_salvar)} mobs")

    # =========================
    #  LOOP DO JOGO
    # =========================
    def run(self):
        if self.musica_jogo:
            pygame.mixer.music.play(-1)
            pygame.mixer.music.set_volume(0.2)
            
        while self.running:
            self.clock.tick(FPS)
            self.handle_events()
            self.update()
            self.draw()
        
    def handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.running = False
            
            elif event.type == pygame.KEYDOWN:
                if self.game_over:
                    if event.key == pygame.K_ESCAPE:
                        self.running = False
                else:
                    if event.key == pygame.K_ESCAPE: 
                        self.pause_game()
                    elif event.key == pygame.K_i:
                        self.inventory.menu_open = False
                        self.inventory.toggle_inventory()
                    # TESTE: Adiciona itens
                    elif event.key == pygame.K_1:
                        self.adicionar_item_teste(0, "Espada", "arma_principal")
                    elif event.key == pygame.K_2:
                        self.adicionar_item_teste(1, "Poção de Vida", "consumivel")
                    elif event.key == pygame.K_3:
                        self.adicionar_item_teste(2, "Escudo", "arma_secundaria")
                    elif event.key == pygame.K_4:
                        self.adicionar_item_teste(3, "Chave", "consumivel")
                    # TESTE: Adiciona múltiplos itens
                    elif event.key == pygame.K_5:
                        for i in range(3):
                            self.adicionar_item_teste(1, "Poção de Vida", "consumivel")
                    # DEBUG: Mostra estado atual
                    elif event.key == pygame.K_0:
                        self.debug_estado_itens()

            self.inventory.handle_event(event)

    def adicionar_item_teste(self, item_id, item_nome, item_tipo):
        """Método para adicionar itens de teste"""
        if hasattr(self.player.status, 'adicionar_item'):
            self.player.status.adicionar_item(item_id, item_nome, item_tipo)
            print(f"🎁 Item de teste '{item_nome}' adicionado!")
            
            # Mostra quantidades atuais
            contagem = {}
            for item in self.player.status.inventario:
                chave = item.get('name', 'Item')
                contagem[chave] = contagem.get(chave, 0) + 1
            print(f"📊 Inventário atual: {contagem}")
            
            # DEBUG: Mostra também itens equipados
            print(f"🛡️ Itens equipados: {[item['name'] for item in self.player.status.equipped_items]}")
        else:
            print("❌ Sistema de inventário não disponível")

    def update(self):
        if self.game_over:
            return  
            
        keys = pygame.key.get_pressed()
        self.player.update(keys, self.map.obstaculos)
        self.calculate_camera_offset()
        
        if self.damage_cooldown > 0:
            self.damage_cooldown -= 1
        
        self.check_player_attack()
        
        for mob in self.mobs:
            mob.update(self.player)
            self.check_mob_damage(mob)
        
        self.update_hud()

    # =========================
    #  SISTEMAS DE COMBATE
    # =========================
    def check_player_attack(self):
        if self.player.attacking:
            attack_hitbox = self.player.get_attack_hitbox()
            if attack_hitbox:
                for mob in self.mobs:
                    if attack_hitbox.colliderect(mob.rect):
                        mob_morreu = mob.tomar_dano(self.player.attack_damage)
                        if mob_morreu:
                            mob.kill()
                            print("Mob eliminado!")

    def check_mob_damage(self, mob):
        if self.player.rect.colliderect(mob.hitbox):
            if self.damage_cooldown == 0:
                self.apply_damage_to_player(mob.dano)
                self.damage_cooldown = self.damage_cooldown_max

    def apply_damage_to_player(self, dano):
        self.player.status.tomar_dano(dano)
        if self.som_dano:
            self.som_dano.play()

        if self.player.status.vida_atual <= 0:
            self.game_over_screen()

    # =========================
    #  SISTEMAS DE MENU E PAUSA
    # =========================
    def pause_game(self):
        """Pausa o jogo e abre o menu de pausa"""
        fundo = self.tela.copy()
        menu = Menu(self.tela, tipo='pausa', fundo=fundo)
        acao = menu.run()

        if acao == "salvar":
            self.salvar_jogo()
        elif acao == "salvar_sair":
            self.salvar_jogo()
            print("💾 Jogo salvo. Saindo...")
            pygame.quit()
            exit()
        elif acao == "continuar":
            print("🔄 Continuando o jogo...")


    def game_over_screen(self):
        self.game_over = True
        pygame.mixer.music.stop()
        print("GAME OVER")

    def update_hud(self):
        pass

    # =========================
    #  RENDERIZAÇÃO
    # =========================
    def draw(self):
        if self.game_over:
            return
            
        self.map.draw(self.tela, self.calculate_camera_offset())

        for sprite in self.all_sprites:
            self.tela.blit(sprite.image, (sprite.rect.x - self.camera_offset[0], sprite.rect.y - self.camera_offset[1]))
        
        for mob in self.mobs:
            mob.draw_health_bar(self.tela, self.camera_offset)
        
        self.player.draw_attack_hitbox(self.tela, self.camera_offset)
        self.hud.draw(self.fundo_hud, self.hp, self.mana, self.player.status)
        self.inventory.draw(self.tela, self.icons)
        
        # DEBUG: Mostra estado atual em tempo real
        if hasattr(self.player.status, 'inventario'):
            contagem_inventario = {}
            for item in self.player.status.inventario:
                chave = item.get('name', 'Item')
                contagem_inventario[chave] = contagem_inventario.get(chave, 0) + item.get('quantity', 1)
            
            equipados = [item['name'] for item in self.player.status.equipped_items]
            print(f"🎒 Inv: {contagem_inventario} | 🛡️ Eq: {equipados}", end="\r")
        
        pygame.display.flip()

    # =========================
    #  CÂMERA
    # =========================
    def calculate_camera_offset(self):
        half_largura = self.tela.get_width() // 2
        half_altura = self.tela.get_height() // 2
        offset_x = self.player.rect.centerx - half_largura
        offset_y = self.player.rect.centery - half_altura
        offset_x = max(0, min(offset_x, self.map_largura - self.tela.get_width()))
        offset_y = max(0, min(offset_y, self.map_altura - self.tela.get_height()))
        self.camera_offset = [offset_x, offset_y]
        return self.camera_offset