import pygame

class Playerstatus:
    def __init__(self):
        #atributos do jogador
        self.level = 1
        self.exp = 0
        self.next_level_exp = 10

        self.vida_max = 100
        self.vida_atual = self.vida_max
        self.mana_max = 50
        self.mana_atual = self.mana_max

        self.inventario = [{
            'id': 0,
            'name': 'Espada',
            'type': 'arma_principal',
            'quantity': 1
        },{
            'id': 1,
            'name': 'Garrafa de Água',
            'type': 'consumivel',
            'quantity': 5
        }]
  
        self.equipped_items = [] 

        self.forca = 10
        self.defesa = 5
        
        # SISTEMA DE REGENERAÇÃO DE ESTAMINA
        self.ultima_regeneracao = 0
        self.regeneracao_delay = 1000  # 1 segundo entre regenerações
        self.regeneracao_quantidade = 5  # Quantidade de estamina regenerada

    def tomar_dano(self, dano=10):
        self.vida_atual = max(0, self.vida_atual - dano)

    def curar(self, quantidade):
        self.vida_atual = min(self.vida_max, self.vida_atual + quantidade)

    def usar_mana(self, quantidade):
        """Usa estamina (mana) - retorna True se tem estamina suficiente"""
        if self.mana_atual >= quantidade:
            self.mana_atual = max(0, self.mana_atual - quantidade)
            return True
        return False  # Não tem estamina suficiente

    def restaurar_mana(self, quantidade):
        self.mana_atual = min(self.mana_max, self.mana_atual + quantidade)
    
    def regenerar_estamina(self):
        """Regenera estamina gradualmente ao longo do tempo"""
        tempo_atual = pygame.time.get_ticks()
        if tempo_atual - self.ultima_regeneracao >= self.regeneracao_delay:
            if self.mana_atual < self.mana_max:
                self.restaurar_mana(self.regeneracao_quantidade)
                self.ultima_regeneracao = tempo_atual
                print(f"Estamina regenerada: {self.mana_atual}/{self.mana_max}")  # Debug opcional
    
    def ganhar_exp(self, quantidade):
        self.exp += quantidade
        if self.exp >= self.next_level_exp:
            self.level_up()

    def level_up(self):
        self.level += 1
        self.exp -= self.next_level_exp
        self.next_level_exp = int(10 * (1.04 ** (self.level - 1)))

        self.vida_max += 20
        self.mana_max += 10
        self.forca += 5
        self.defesa += 3

        self.vida_atual = self.vida_max
        self.mana_atual = self.mana_max

    def adicionar_item(self, id, name, type, quantity=1):
        """Adiciona um item ao inventário"""
        for item in self.inventario:
            if item['id'] == id:
                item['quantity'] += quantity
                print(f"✅ Item '{name}' adicionado. Quantidade: {item['quantity']}")
                return
        # Se o item não existe, cria novo
        novo_item = {
            'id': id,
            'name': name,
            'type': type,
            'quantity': quantity
        }
        self.inventario.append(novo_item)
        print(f"✅ Novo item '{name}' adicionado. Quantidade: {quantity}")
    
    def remover_item(self, id, name, type, quantity=1):
        """Remove um item do inventário - CORREÇÃO: busca por ID e remove quantidade específica"""
        print(f"🔍 Tentando remover item: ID={id}, Nome='{name}', Tipo='{type}', Quantidade={quantity}")
        
        for i, item in enumerate(self.inventario):
            if item['id'] == id:
                print(f"📦 Item encontrado: {item}")
                
                # Remove a quantidade especificada
                item['quantity'] -= quantity
                print(f"📉 Quantidade após remoção: {item['quantity']}")
                
                # Se a quantidade chegar a zero ou menos, remove o item
                if item['quantity'] <= 0:
                    item_removido = self.inventario.pop(i)
                    print(f"🗑️ Item '{item_removido['name']}' completamente removido do inventário")
                else:
                    print(f"📦 Item '{item['name']}' atualizado. Nova quantidade: {item['quantity']}")
                return True  # Item encontrado e processado
        
        print(f"❌ Item não encontrado no inventário: ID={id}, Nome='{name}'")
        return False  # Item não encontrado

    def equipar_item(self, item):
        """Equipa um item - CORREÇÃO: método específico para equipar"""
        print(f"🛡️ Tentando equipar item: {item}")
        
        # Remove o item do inventário
        if self.remover_item(item['id'], item['name'], item['type'], 1):
            # Adiciona aos itens equipados
            self.equipped_items.append(item)
            print(f"✅ Item '{item['name']}' equipado com sucesso!")
            print(f"🎒 Itens equipados: {[item['name'] for item in self.equipped_items]}")
            return True
        else:
            print(f"❌ Falha ao equipar item '{item['name']}'")
            return False

    def desequipar_item(self, item):
        """Desequipa um item - CORREÇÃO: método específico para desequipar"""
        print(f"🛡️ Tentando desequipar item: {item}")
        
        if item in self.equipped_items:
            self.equipped_items.remove(item)
            self.adicionar_item(item['id'], item['name'], item['type'], 1)
            print(f"✅ Item '{item['name']}' desequipado com sucesso!")
            return True
        else:
            print(f"❌ Item '{item['name']}' não estava equipado")
            return False

    def get_status(self):
        return {
            "level": self.level,
            "exp": self.exp,
            "next_level_exp": self.next_level_exp,
            "vida_atual": self.vida_atual,
            "vida_max": self.vida_max,
            "mana_atual": self.mana_atual,
            "mana_max": self.mana_max,
            "forca": self.forca,
            "defesa": self.defesa,
            "inventario": self.inventario,
            "equipped_items": self.equipped_items
        }