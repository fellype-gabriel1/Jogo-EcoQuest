import pygame
from status import Playerstatus

class Player(pygame.sprite.Sprite):
    def __init__(self, x, y, spritesheets_path):
        """
        Inicializar jogador
        param x: posição inicial do jogador no eixo x
        param y: posição inicial do jogador no eixo y
        param spritesheets_path: caminho para imagem da spritesheet.
        """
        super().__init__()
        self.x = x
        self.y = y
        self.speed = 3

        # Sistema de status do jogador
        self.status = Playerstatus()

        self.frame_largura = 16
        self.frame_altura = 16
        self.zoom = 2.5

        self.spritesheet = pygame.image.load(spritesheets_path).convert_alpha()
        self.frames = self.load_frames()

        self.direction = "down"
        self.current_frame = 0
        self.last_update = pygame.time.get_ticks()

        # Sistema de ataque
        self.attacking = False
        self.attack_frames = self.load_attack_frames()
        self.attack_frame = 0
        self.attack_duration = 200  # Duração do ataque em ms
        self.attack_start_time = 0
        self.attack_damage = 1  # Dano do ataque do player
        self.attack_range = 100  

        self.image = self.frames["down"][0]
        self.image = pygame.transform.scale(
            self.image,
            (self.frame_largura * self.zoom, self.frame_altura * self.zoom)
        )
        self.rect = self.image.get_rect(topleft=(self.x, self.y))

        # Área de colisão do ataque
        self.attack_rect = pygame.Rect(0, 0, 0, 0)

    def load_frames(self):
        frames = {
            "down": [],
            "left": [],
            "right": [],
            "up": []
        }
        for linha, direcao in enumerate(["down", "left", "right", "up"]):
            for coluna in range(4):
                frame = self.spritesheet.subsurface(
                    (coluna * self.frame_largura, linha * self.frame_altura,
                     self.frame_largura, self.frame_altura)
                )
                frames[direcao].append(frame)
            frames[direcao].append(frames[direcao][1])  # frame parado
        return frames

    def load_attack_frames(self):
        """Carrega os frames de ataque"""
        try:
            # Caminhos possíveis para a spritesheet de ataque
            caminhos_ataque = [
                "../img/tileset/personagens/Attack.png",
                "img/tileset/personagens/Attack.png"
            ]
            
            attack_spritesheet = None
            for caminho in caminhos_ataque:
                try:
                    attack_spritesheet = pygame.image.load(caminho).convert_alpha()
                    print(f"Spritesheet de ataque carregada de: {caminho}")
                    break
                except pygame.error:
                    continue
            
            if attack_spritesheet is None:
                print("Não foi possível carregar a spritesheet de ataque")
                return {"down": [], "left": [], "right": [], "up": []}
            
            attack_frames = {
                "down": [],
                "left": [],
                "right": [],
                "up": []
            }
            
            # Assumindo que a spritesheet de ataque tem a mesma estrutura
            for linha, direcao in enumerate(["down", "left", "right", "up"]):
                for coluna in range(4):  # 4 frames de ataque por direção
                    frame = attack_spritesheet.subsurface(
                        (coluna * self.frame_largura, linha * self.frame_altura,
                         self.frame_largura, self.frame_altura)
                    )
                    attack_frames[direcao].append(frame)
            
            return attack_frames
        except Exception as e:
            print(f"Erro ao carregar spritesheet de ataque: {e}")
            # Retorna frames vazios se não conseguir carregar
            return {"down": [], "left": [], "right": [], "up": []}

    def update(self, keys, obstaculos):
        # Verifica se deve atacar
        if keys[pygame.K_k] and not self.attacking:
            self.start_attack()
        
        # Atualiza o ataque se estiver atacando
        if self.attacking:
            self.update_attack()
            return  # Não move durante o ataque
        
        dx, dy = 0, 0
        if keys[pygame.K_w]:  # Para cima
            dy = -self.speed
            self.direction = "left"
        elif keys[pygame.K_s]:  # Para baixo
            dy = self.speed
            self.direction = "down"

        if keys[pygame.K_a]:  # Para esquerda
            dx = -self.speed
            self.direction = "right"
        elif keys[pygame.K_d]:  # Para direita
            dx = self.speed
            self.direction = "up"

        # movimento diagonal mais suave
        if dx != 0 and dy != 0:
            dx *= 0.7071
            dy *= 0.7071

        # Sistema de colisão melhorado
        self.move_with_collision(dx, dy, obstaculos)

        # animação
        if dx != 0 or dy != 0:
            self.animate()
        else:
            frame = self.frames[self.direction][0]
            self.image = pygame.transform.scale(
                frame,
                (self.frame_largura * self.zoom, self.frame_altura * self.zoom)
            )
            self.rect = self.image.get_rect(topleft=(self.x, self.y))

    def move_with_collision(self, dx, dy, obstaculos):
        """Sistema de colisão melhorado que evita travamentos e tremores"""
        # Salva a posição original
        old_x, old_y = self.x, self.y
        
        # Move em X primeiro
        self.x += dx
        self.rect.x = int(self.x)
        
        # Verifica colisão em X
        collision_x = False
        for obs in obstaculos:
            if self.rect.colliderect(obs):
                collision_x = True
                # Ajusta a posição para ficar exatamente ao lado do obstáculo
                if dx > 0:  # movendo para direita
                    self.rect.right = obs.left
                elif dx < 0:  # movendo para esquerda
                    self.rect.left = obs.right
                self.x = self.rect.x
                break
        
        # Move em Y (independente da colisão em X para permitir deslizar)
        self.y += dy
        self.rect.y = int(self.y)
        
        # Verifica colisão em Y
        for obs in obstaculos:
            if self.rect.colliderect(obs):
                # Ajusta a posição para ficar exatamente ao lado do obstáculo
                if dy > 0:  # movendo para baixo
                    self.rect.bottom = obs.top
                elif dy < 0:  # movendo para cima
                    self.rect.top = obs.bottom
                self.y = self.rect.y
                break

    def start_attack(self):
        """Inicia o ataque"""
        self.attacking = True
        self.attack_frame = 0
        self.attack_start_time = pygame.time.get_ticks()
        print(f"Ataque iniciado na direção: {self.direction}")

    def update_attack(self):
        """Atualiza a animação de ataque"""
        current_time = pygame.time.get_ticks()
        
        # Atualiza a hitbox do ataque
        self.update_attack_hitbox()
        
        # Verifica se o ataque terminou
        if current_time - self.attack_start_time >= self.attack_duration:
            self.attacking = False
            self.attack_frame = 0
            # Volta para a animação normal
            frame = self.frames[self.direction][0]
            self.image = pygame.transform.scale(
                frame,
                (self.frame_largura * self.zoom, self.frame_altura * self.zoom)
            )
            self.rect = self.image.get_rect(topleft=(self.x, self.y))
            return
        
        # Atualiza o frame de ataque
        attack_frames = self.attack_frames[self.direction]
        if attack_frames and len(attack_frames) > 0:  # Se há frames de ataque disponíveis
            frame_duration = self.attack_duration // len(attack_frames)
            self.attack_frame = (current_time - self.attack_start_time) // frame_duration
            self.attack_frame = min(self.attack_frame, len(attack_frames) - 1)
            
            # Atualiza a imagem
            frame = attack_frames[self.attack_frame]
            self.image = pygame.transform.scale(
                frame,
                (self.frame_largura * self.zoom, self.frame_altura * self.zoom)
            )
            self.rect = self.image.get_rect(topleft=(self.x, self.y))
        else:
            # Se não há frames de ataque, usa um frame especial da animação normal
            frame = self.frames[self.direction][1]  # Frame de movimento
            self.image = pygame.transform.scale(
                frame,
                (self.frame_largura * self.zoom, self.frame_altura * self.zoom)
            )
            self.rect = self.image.get_rect(topleft=(self.x, self.y))

    def update_attack_hitbox(self):
        """Atualiza a posição da hitbox do ataque de acordo com a direção."""
        largura = 10
        altura = 10

        if self.direction == "left":
            self.attack_rect = pygame.Rect(
                self.rect.centerx - largura // 2,
                self.rect.top - altura,
                largura,
                altura
            )

        elif self.direction == "down":
            self.attack_rect = pygame.Rect(
                self.rect.centerx - largura // 2,
                self.rect.bottom,
                largura,
                altura
            )

        elif self.direction == "right":
            self.attack_rect = pygame.Rect(
                self.rect.left - largura,
                self.rect.centery - altura // 2,
                largura,
                altura
            )

        elif self.direction == "up":
            self.attack_rect = pygame.Rect(
                self.rect.right,
                self.rect.centery - altura // 2,
                largura,
                altura
            )

    def get_attack_hitbox(self):
        """Retorna a área de colisão do ataque"""
        return self.attack_rect if self.attacking else None

    # (OPCIONAL) Método para debug - desenha a hitbox do ataque
    def draw_attack_hitbox(self, tela, camera_offset):
        """Desenha a hitbox do ataque para debug (opcional)"""
        if self.attacking:
            screen_x = self.attack_rect.x - camera_offset[0]
            screen_y = self.attack_rect.y - camera_offset[1]
            pygame.draw.rect(tela, (255, 255, 0), 
                            (screen_x, screen_y, self.attack_rect.width, self.attack_rect.height), 2)

    def animate(self):
        now = pygame.time.get_ticks()
        if now - self.last_update > 150:  # troca de frame a cada 150ms
            self.last_update = now
            self.current_frame = (self.current_frame + 1) % len(self.frames[self.direction])
            self.image = self.frames[self.direction][self.current_frame]

        frame = self.frames[self.direction][self.current_frame]
        self.image = pygame.transform.scale(
            frame,
            (self.frame_largura * self.zoom, self.frame_altura * self.zoom)
        )