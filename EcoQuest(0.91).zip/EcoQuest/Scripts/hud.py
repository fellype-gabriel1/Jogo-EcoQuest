import pygame

class Hud:
    def __init__(self, tela):
        self.tela = tela

    def draw(self, fundo_hud, hp, mana, player_status):
        self.pos_inicio = 20
        self.espacamento = 45
        self.margem = 5

        # desenha os fundos das garrafas
        self.tela.blit(fundo_hud, (self.pos_inicio, self.pos_inicio))
        self.tela.blit(fundo_hud, (self.pos_inicio + self.espacamento, self.pos_inicio))

        # Barras de hp e mana usando o status real do jogador
        self.draw_bar_vertical_scale(
            player_status.vida_atual, player_status.vida_max,
            hp, (self.pos_inicio + self.margem, self.pos_inicio + 15)
        )

        self.draw_bar_vertical_scale(
            player_status.mana_atual, player_status.mana_max,
            mana, (self.pos_inicio + self.espacamento + self.margem, self.pos_inicio + 15)
        )

    def draw_bar_vertical_scale(self, valor_atual, valor_maximo, img, pos):
        proporcao = valor_atual / valor_maximo

        largura, altura_original = img.get_size()
        nova_altura = max(2, int(altura_original * proporcao))

        # Redimensiona a altura proporcional
        barra_reduzida = pygame.transform.scale(img, (largura, nova_altura))

        # Faz o líquido encher/esvaziar de baixo para cima
        self.tela.blit(
            barra_reduzida,
            (pos[0], pos[1] + (altura_original - nova_altura))
        )