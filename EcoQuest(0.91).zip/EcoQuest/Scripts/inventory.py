import pygame
from config import TELA_LARGURA, TELA_ALTURA, CORES
from status import Playerstatus
from player import Player
import time

class Inventory:
    def __init__(self):
        self.player_status = Playerstatus()

        self.player = Player(0 ,0 ,r'img\tileset\personagens\Nilo_reorganizado.png')

        self.itens = []

        self.open = False
        self.menu_open = False
        self.selected_item = None

        self.slot_size = 32
        self.espaco_entre_slots = 5
        self.rows = 8
        self.cols = 10
        self.equip_sections_height = 150

        inventory_width = (self.slot_size + self.espaco_entre_slots) * self.cols + self.espaco_entre_slots
        inventory_height = (self.slot_size + self.espaco_entre_slots) * self.rows + self.espaco_entre_slots + self.equip_sections_height
        self.inventory_surface = pygame.Surface((inventory_width, inventory_height))

        self.inventory_rect = self.inventory_surface.get_rect(center=(TELA_LARGURA // 2, TELA_ALTURA // 2))

        self.fonte = pygame.font.SysFont(r"PressStart2P-Regular.ttf", 18)

        self.last_click_time = 0
        self.double_click_threshold = 0.3

    def toggle_inventory(self):
        self.open = not self.open


    def draw(self, tela, icones):
        if not self.open:
            return
        self.inventory_surface.fill(CORES["marrom escuro"])

        pygame.draw.rect(
            self.inventory_surface,
            CORES["cinza"],
            (0, 0, self.inventory_rect.width, self.equip_sections_height),
            3
        )
        self.draw_player()

        self.draw_equip_slots(icones)

        self.draw_slots()

        self.draw_items(icones)

        tela.blit(self.inventory_surface, self.inventory_rect.topleft)

        if self.menu_open:
            self.draw_menu(tela)

    def draw_player(self):
        player_frame = self.player.frames['down'][0]
        player_frame_width = self.player.frame_largura
        self.player_box_width = ((self.slot_size + self.espaco_entre_slots) * self.cols / 2 - self.espaco_entre_slots)
        self.player_box_height = self.equip_sections_height - 2 * self.espaco_entre_slots

        # Desenha o fundo do player primeiro
        pygame.draw.rect(
            self.inventory_surface,
            CORES["marrom claro"],
            (self.espaco_entre_slots, self.espaco_entre_slots, self.player_box_width, self.player_box_height))

        escala = (self.player_box_height *0.7)/player_frame_width

        resized_player = pygame.transform.smoothscale(player_frame, ((player_frame_width * escala), (player_frame_width * escala)))

        player_x = self.espaco_entre_slots + (self.player_box_width - resized_player.get_width()) // 2
        player_y = self.espaco_entre_slots + (self.player_box_height - resized_player.get_height()) // 2

        self.inventory_surface.blit(resized_player, (player_x, player_y))

    def draw_slots(self):
        for row in range(self.rows):
            for col in range(self.cols):
                slot_x = col * (self.slot_size + self.espaco_entre_slots) + self.espaco_entre_slots
                slot_y = row * (self.slot_size + self.espaco_entre_slots) + self.espaco_entre_slots + self.equip_sections_height
                pygame.draw.rect(
                    self.inventory_surface,
                    CORES["marrom claro"],
                    (slot_x, slot_y, self.slot_size, self.slot_size)
                )

    def draw_menu(self, tela):
        equip_slot_names = [slot[0] for slot in self.equip_slot]
        menu_options = []
        if self.selected_item:
            if self.selected_item['type'] in equip_slot_names:
                menu_options.append('Equipar')

            if self.selected_item['type'] == 'consumivel':
                menu_options.append('Consumir')
            menu_options.append('Descartar')
        else:
            self.menu_open = False
            return

        menu_width = 100
        button_height = 30
        menu_x, menu_y = self.menu_position

        # retângulo de fundo do menu
        menu_rect = pygame.Rect(
            menu_x, 
            menu_y, 
            menu_width, 
            button_height * len(menu_options) + self.espaco_entre_slots
        )
        pygame.draw.rect(tela, CORES["preto"], menu_rect)
        pygame.draw.rect(tela, CORES["branco"], menu_rect, 2)

        self.menu_buttons = {}

        for i, option in enumerate(menu_options):
            option_rect = pygame.Rect(
                menu_x + 5,
                menu_y + i * button_height + 5,
                menu_width - 10,
                button_height - 5
            )
            self.menu_buttons[option] = option_rect

            # botão de fundo
            pygame.draw.rect(tela, CORES["cinza"], option_rect)

            # texto centralizado
            text_surface = self.fonte.render(option, True, CORES["preto"])
            text_rect = text_surface.get_rect(center=option_rect.center)
            tela.blit(text_surface, text_rect)



    def draw_items(self, icons):
        for index, item in enumerate(self.player_status.inventario):
            item_x = (index % self.cols) * (self.slot_size + self.espaco_entre_slots) + self.espaco_entre_slots
            item_y = (index // self.cols) * (self.slot_size + self.espaco_entre_slots) + self.espaco_entre_slots + self.equip_sections_height

            icon_col = item['id'] % self.cols
            icon_row = item['id'] // self.cols

            item_icon = icons.subsurface(
                (icon_col * self.slot_size, icon_row * self.slot_size, self.slot_size, self.slot_size)
            )
            self.inventory_surface.blit(item_icon, (item_x, item_y))

            quantity_text = pygame.font.SysFont("PressStart2P-Regular.ttf", 24).render(str(item['quantity']), True, CORES["branco"])
            self.inventory_surface.blit(quantity_text, (item_x , item_y ))

    def draw_equip_slots(self, icons=None):
        center_x = self.player_box_width + (self.player_box_width // 2) - self.slot_size // 4
        center_x_left = center_x - (self.player_box_width // 4) + self.slot_size // 4
        center_x_right = center_x + (self.player_box_width // 4) + self.slot_size // 4

        # Definição dos slots (nome, posição X, posição Y)
        self.equip_slot = [
            ("arma_principal", center_x_left, self.espaco_entre_slots + 2 + self.slot_size * 1.5),
            ("arma_secundaria", center_x_right, self.espaco_entre_slots + 2 + self.slot_size * 1.5)
            ]
        
        equipped_items = {item['type']: item for item in self.player_status.equipped_items}



        for slot_name, x, y in self.equip_slot:
        # fundo do slot
            pygame.draw.rect(
                self.inventory_surface,
                CORES["marrom claro"],
                (x, y, self.slot_size, self.slot_size
            ))

            if slot_name in equipped_items:
                item = equipped_items[slot_name]

                icon_col = item['id'] % self.cols
                icon_row = item['id'] // self.cols
                item_icon = icons.subsurface(
                    (icon_col * self.slot_size, icon_row * self.slot_size, self.slot_size, self.slot_size)
                )
                self.inventory_surface.blit(item_icon, (x, y))
            
        


    def handle_event(self, event):
        if not self.open:
            return
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            
            current_time = time.time()
            is_double_click = (current_time - self.last_click_time) < self.double_click_threshold
            self.last_click_time = current_time
            
            if not self.menu_open:
                rel_x , rel_y = mouse_x - self.inventory_rect.x, mouse_y - self.inventory_rect.y

         

                for index, item in enumerate(self.player_status.inventario):
                    x = (index % self.cols) * (self.slot_size + self.espaco_entre_slots) + self.espaco_entre_slots
                    y = (index // self.cols) * (self.slot_size + self.espaco_entre_slots) + self.espaco_entre_slots + self.equip_sections_height
                    item_rect = pygame.Rect(x, y, self.slot_size, self.slot_size)

                    if item_rect.collidepoint(rel_x, rel_y):
                        self.selected_item = item
                        if event.button == 3:
                            self.menu_position = (mouse_x, mouse_y)
                            self.menu_open = True
                        elif is_double_click:
                            equip_slot_names = [slot[0] for slot in self.equip_slot]
                            if item['type'] in equip_slot_names:
                                self.handle_menu_action('Equipar')
                        return
                for slot_name, x, y in self.equip_slot:
                    slot_rect = pygame.Rect(x, y, self.slot_size, self.slot_size)
                    if slot_rect.collidepoint(rel_x, rel_y):
                        equipped_item = next((itm for itm in self.player_status.equipped_items if itm['type'] == slot_name), None)
                        self.selected_item = equipped_item
                        if equipped_item:
                            if is_double_click:
                                self.handle_menu_action('Desequipar')
            else:
                cliked_inside = any(rect.collidepoint(mouse_x, mouse_y) for rect in self.menu_buttons.values())
                if not cliked_inside:
                    self.menu_open = False
                    return
                else:
                    for option, rect in self.menu_buttons.items():
                        if rect.collidepoint(mouse_x, mouse_y):
                            self.handle_menu_action(option)
                            self.menu_open = False
                            return
    def handle_menu_action(self, option):
        if not self.selected_item:
            return
        
        print(f"🎯 Ação do menu: {option} no item: {self.selected_item}")
        
        if option == 'Equipar':
            # CORREÇÃO: Usa o método equipar_item do Playerstatus
            if self.player_status.equipar_item(self.selected_item):
                print(f"✅ '{self.selected_item['name']}' equipado com sucesso!")
            else:
                print(f"❌ Falha ao equipar '{self.selected_item['name']}'")

        elif option == 'Desequipar':
            # CORREÇÃO: Usa o método desequipar_item do Playerstatus
            if self.player_status.desequipar_item(self.selected_item):
                print(f"✅ '{self.selected_item['name']}' desequipado com sucesso!")
            else:
                print(f"❌ Falha ao desequipar '{self.selected_item['name']}'")

        elif option == 'Consumir':
            self.selected_item['quantity'] -= 1
            if self.selected_item['quantity'] <= 0:
                self.player_status.inventario.remove(self.selected_item)
            print(f"🍶 '{self.selected_item['name']}' consumido!")

        elif option == 'Descartar':
            # CORREÇÃO: Usa o método remover_item corrigido
            if self.player_status.remover_item(
                self.selected_item['id'],
                self.selected_item['name'],
                self.selected_item['type'], 1):
                print(f"🗑️ '{self.selected_item['name']}' descartado!")
            else:
                print(f"❌ Falha ao descartar '{self.selected_item['name']}'")
        
        self.selected_item = None

        

if __name__ == "__main__":
    pygame.init()
    tela = pygame.display.set_mode((TELA_LARGURA, TELA_ALTURA))
    clock = pygame.time.Clock()

    icones = pygame.image.load(r'img\itens\Sprite.png').convert_alpha()

    inventory = Inventory()

    running = True
    while running:
        tela.fill(CORES["preto"])
        if inventory.open:
            inventory.draw(tela, icones)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_i:
                    inventory.menu_open = False
                    inventory.toggle_inventory()
                else:
                    inventory.handle_event(event)
            elif event.type == pygame.MOUSEBUTTONDOWN:
                inventory.handle_event(event)

        pygame.display.flip()
